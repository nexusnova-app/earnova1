EARNOVA starter package (Firebase project: earnova-platform-be3ac)

FILES
- index.html: single-page member/admin website
- firestore.rules: Firestore access rules

SETUP (Android / Acode)
1. Download and unzip this package.
2. Replace your existing index.html with the included index.html.
3. Firebase Console > Firestore Database > Rules: replace all rules with firestore.rules and Publish.
4. Confirm Firebase Authentication > Sign-in method > Email/Password is enabled.
5. Upload/publish index.html to the same hosting location you currently use.
6. Sign in with the admin account whose UID is:
   tuzcowIk9jZ9czNaqkWAKJb40Zf2

IMPORTANT SAFETY LIMITATIONS
- This is a starter MVP, not a production-ready financial platform.
- Admin review and wallet changes are performed by the authenticated admin browser. Keep the admin account secure and enable 2-step verification.
- A withdrawal request does not reserve funds. If multiple requests are pending, the admin must process only requests whose amount is still covered by the current wallet balance. The Paid action re-checks the current balance and refuses to overdraw.
- The site does NOT send bKash/Nagad payments automatically. Admin manually sends money, then enters the real transaction ID and marks Paid.
- Only approve work when the partner/client has actually verified and funded the reward. A task's reward is not proof that the platform has money.
- Do not add fake starting balances or manually credit money that is not funded.
- Referral is collected at registration but referral rewards are not paid by this starter.
- Support tickets are saved; an admin ticket inbox UI is not included yet.
- Before real-money launch, move all wallet credits/debits and admin actions to a trusted server (e.g. Cloud Functions/your own backend), add audit logs, idempotency, rate limits, and independent security review. Firebase Blaze may incur charges.
- Firestore rules protect member access but cannot replace a trusted backend for production financial accounting.
